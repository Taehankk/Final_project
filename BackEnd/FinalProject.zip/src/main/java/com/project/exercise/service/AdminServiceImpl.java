package com.project.exercise.service;

public class AdminServiceImpl {

}
