package com.project.exercise.dto;

public class Problem {
	private String problemId;
	private String problemName;
	private String problemAnswer;
	private int score;

	public Problem() {
	}

	public Problem(String problemId, String problemName, String problemAnswer, int score) {
		this.problemId = problemId;
		this.problemName = problemName;
		this.problemAnswer = problemAnswer;
		this.score = score;
	}

	public String getProblemId() {
		return problemId;
	}

	public void setProblemId(String problemId) {
		this.problemId = problemId;
	}

	public String getProblemName() {
		return problemName;
	}

	public void setProblemName(String problemName) {
		this.problemName = problemName;
	}

	public String getProblemAnswer() {
		return problemAnswer;
	}

	public void setProblemAnswer(String problemAnswer) {
		this.problemAnswer = problemAnswer;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	@Override
	public String toString() {
		return "Problem [problemId=" + problemId + ", problemName=" + problemName + ", problemAnswer=" + problemAnswer
				+ ", score=" + score + "]";
	}
}