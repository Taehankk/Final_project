package com.project.exercise.controller;

public class AdminController {

}
